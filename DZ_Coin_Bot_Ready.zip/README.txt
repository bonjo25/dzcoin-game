DZ Coin Bot
============

هذا بوت Telegram للعبة حجر-ورق-مقص مع نقاط DZC افتراضية.

التشغيل:
1. ثبّت Python.
2. نفّذ: pip install -r requirements.txt
3. افتح bot.py واستبدل YOUR_BOT_TOKEN_HERE بتوكن BotFather.
4. شغّل: python bot.py

الأوامر:
/start أو /game = فتح اللعبة
/balance = عرض الرصيد

يتم حفظ الأرصدة والإحصائيات في dzcoin_users.json.
DZC في هذا المشروع نقاط افتراضية داخل البوت وليست عملة مالية.

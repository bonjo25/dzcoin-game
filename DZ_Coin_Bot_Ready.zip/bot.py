import random, json, os
import telebot
from telebot import types

TOKEN = "YOUR_BOT_TOKEN_HERE"
bot = telebot.TeleBot(TOKEN, parse_mode="Markdown")
DATA_FILE = "dzcoin_users.json"

WIN_REWARD = 10
DRAW_REWARD = 2
CHOICES = ["rock", "paper", "scissors"]
NAMES = {"rock": "🪨 حجر", "paper": "📄 ورق", "scissors": "✂️ مقص"}

def load_users():
    if not os.path.exists(DATA_FILE):
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

users = load_users()

def save_users():
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, ensure_ascii=False, indent=2)

def get_user(user):
    uid = str(user.id)
    if uid not in users:
        users[uid] = {"name": user.first_name or "لاعب", "coins": 0,
                      "wins": 0, "losses": 0, "draws": 0}
        save_users()
    return users[uid]

def keyboard():
    m = types.InlineKeyboardMarkup(row_width=3)
    m.add(
        types.InlineKeyboardButton("🪨 حجر", callback_data="game_rock"),
        types.InlineKeyboardButton("📄 ورق", callback_data="game_paper"),
        types.InlineKeyboardButton("✂️ مقص", callback_data="game_scissors")
    )
    m.add(types.InlineKeyboardButton("💰 رصيدي", callback_data="balance"))
    return m

def result_keyboard():
    m = types.InlineKeyboardMarkup(row_width=3)
    m.add(
        types.InlineKeyboardButton("🪨 حجر", callback_data="game_rock"),
        types.InlineKeyboardButton("📄 ورق", callback_data="game_paper"),
        types.InlineKeyboardButton("✂️ مقص", callback_data="game_scissors")
    )
    m.add(types.InlineKeyboardButton("💰 رصيدي", callback_data="balance"))
    return m

@bot.message_handler(commands=["start", "game"])
def game(message):
    u = get_user(message.from_user)
    bot.send_message(
        message.chat.id,
        "🪙 *DZ Coin*\n\n"
        "🎮 *لعبة الحظ: حجر، ورق، مقص*\n\n"
        "اختر أحد الخيارات للعب ضد البوت.\n\n"
        f"🏆 الفوز: +{WIN_REWARD} DZC\n"
        f"🤝 التعادل: +{DRAW_REWARD} DZC\n"
        f"💰 رصيدك: *{u['coins']} DZC*",
        reply_markup=keyboard()
    )

@bot.message_handler(commands=["balance"])
def balance(message):
    u = get_user(message.from_user)
    bot.send_message(
        message.chat.id,
        "💰 *رصيد DZ Coin*\n\n"
        f"🪙 الرصيد: *{u['coins']} DZC*\n"
        f"🏆 الفوز: {u['wins']}\n"
        f"😢 الخسارة: {u['losses']}\n"
        f"🤝 التعادل: {u['draws']}"
    )

@bot.callback_query_handler(func=lambda c: c.data == "balance")
def balance_button(call):
    u = get_user(call.from_user)
    bot.answer_callback_query(call.id)
    bot.send_message(
        call.message.chat.id,
        f"💰 *رصيدك: {u['coins']} DZC*\n\n"
        f"🏆 فوز: {u['wins']} | 😢 خسارة: {u['losses']} | 🤝 تعادل: {u['draws']}"
    )

@bot.callback_query_handler(func=lambda c: c.data.startswith("game_"))
def play(call):
    user_choice = call.data[5:]
    if user_choice not in CHOICES:
        bot.answer_callback_query(call.id, "اختيار غير صالح.")
        return

    u = get_user(call.from_user)
    bot_choice = random.choice(CHOICES)

    if user_choice == bot_choice:
        u["draws"] += 1
        u["coins"] += DRAW_REWARD
        outcome = f"🤝 *تعادلنا!* +{DRAW_REWARD} DZC"
    elif ((user_choice == "rock" and bot_choice == "scissors") or
          (user_choice == "paper" and bot_choice == "rock") or
          (user_choice == "scissors" and bot_choice == "paper")):
        u["wins"] += 1
        u["coins"] += WIN_REWARD
        outcome = f"🎉 *مبروك! فزت!* +{WIN_REWARD} DZC"
    else:
        u["losses"] += 1
        outcome = "😢 *خسرت هذه المرة!* حظ أوفر في الجولة القادمة."

    save_users()
    text = (
        "🕹️ *لعبة الحظ: حجر، ورق، مقص*\n\n"
        f"👤 اختيارك: {NAMES[user_choice]}\n"
        f"🤖 اختيار البوت: {NAMES[bot_choice]}\n\n"
        f"{outcome}\n\n"
        f"💰 رصيدك الآن: *{u['coins']} DZC*"
    )
    bot.answer_callback_query(call.id)
    bot.edit_message_text(
        text, call.message.chat.id, call.message.message_id,
        reply_markup=result_keyboard()
    )

print("DZ Coin Bot is running...")
bot.infinity_polling(skip_pending=True)
